/* Browser Automation Tool — WebSocket + Canvas Frontend */
(function () {
  'use strict';

  // ── DOM refs ──────────────────────────────────────────────────────────────────
  const urlInput      = document.getElementById('url-input');
  const goBtn         = document.getElementById('go-btn');
  const recordBtn     = document.getElementById('record-btn');
  const replayBtn     = document.getElementById('replay-btn');
  const speedSelect   = document.getElementById('speed-select');
  const canvas        = document.getElementById('browser-canvas');
  const ctx           = canvas.getContext('2d');
  const frameUrlLabel = document.getElementById('frame-url');
  const recBadge      = document.getElementById('rec-badge');
  const statusText    = document.getElementById('status-text');
  const recList       = document.getElementById('rec-list');
  const recCount      = document.getElementById('rec-count');
  const ovName        = document.getElementById('ov-name');
  const ovBar         = document.getElementById('ov-bar');
  const ovProgress    = document.getElementById('ov-progress');
  const ovCancel      = document.getElementById('ov-cancel');
  const overlay       = document.getElementById('replay-overlay');

  // ── State ─────────────────────────────────────────────────────────────────────
  let ws            = null;
  let wsReady       = false;
  let isRecording   = false;
  let isReplaying   = false;
  let recordings    = [];
  let selectedId    = null;
  let viewport      = { width: 1280, height: 720 };
  let replayingName = '';

  // ── Status helper ─────────────────────────────────────────────────────────────
  function setStatus(msg) { statusText.textContent = msg; }

  // ── WebSocket connection ───────────────────────────────────────────────────────
  function connect() {
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(`${proto}://${location.host}`);

    ws.addEventListener('open', () => {
      wsReady = true;
      setStatus('연결됨. URL을 입력하고 이동하세요.');
    });

    ws.addEventListener('close', () => {
      wsReady = false;
      recordBtn.disabled = true;
      setStatus('서버 연결이 끊겼습니다. 재연결 중…');
      setTimeout(connect, 2000);
    });

    ws.addEventListener('error', () => {});

    ws.addEventListener('message', e => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }
      handleServerMessage(msg);
    });
  }

  function send(obj) {
    if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
  }

  // ── Server message handler ────────────────────────────────────────────────────
  function handleServerMessage(msg) {
    switch (msg.type) {

      case 'ready':
        if (msg.viewport) {
          viewport = msg.viewport;
          canvas.width  = viewport.width;
          canvas.height = viewport.height;
        }
        recordBtn.disabled = false;
        break;

      case 'frame':
        renderFrame(msg.data);
        break;

      case 'url-changed':
        frameUrlLabel.textContent = msg.url || 'about:blank';
        urlInput.value = msg.url && msg.url !== 'about:blank' ? msg.url : urlInput.value;
        break;

      case 'recording-started':
        isRecording = true;
        recordBtn.classList.add('active');
        recordBtn.innerHTML = '<span class="dot"></span> 중지';
        recBadge.classList.remove('hidden');
        replayBtn.disabled = true;
        setStatus('녹화 중… 브라우저에서 자유롭게 상호작용하세요.');
        break;

      case 'recording-event':
        setStatus(`녹화 중… ${msg.count}개 이벤트 캡처됨`);
        break;

      case 'recording-saved':
        isRecording = false;
        recordBtn.classList.remove('active');
        recordBtn.innerHTML = '<span class="dot"></span> 녹화';
        recBadge.classList.add('hidden');
        setStatus(`저장 완료 — ${msg.recording.name} (${msg.recording.eventCount}개 이벤트)`);
        break;

      case 'recording-empty':
        isRecording = false;
        recordBtn.classList.remove('active');
        recordBtn.innerHTML = '<span class="dot"></span> 녹화';
        recBadge.classList.add('hidden');
        setStatus('녹화된 이벤트가 없습니다.');
        break;

      case 'recordings':
        recordings = msg.list || [];
        if (recordings.length > 0 && selectedId === null) {
          selectedId = recordings[recordings.length - 1].id;
          replayBtn.disabled = false;
        }
        if (recordings.length === 0) {
          selectedId = null;
          replayBtn.disabled = true;
        }
        renderList();
        break;

      case 'replay-started':
        isReplaying = true;
        replayBtn.disabled = true;
        recordBtn.disabled = true;
        showOverlay(replayingName, 0, 0);
        break;

      case 'replay-progress':
        updateOverlay(msg.done, msg.total);
        break;

      case 'replay-done':
        isReplaying = false;
        replayBtn.disabled = selectedId === null;
        recordBtn.disabled = false;
        hideOverlay();
        setStatus(`재생 완료 — ${replayingName}`);
        break;

      case 'error':
        setStatus('오류: ' + (msg.message || '알 수 없는 오류'));
        break;
    }
  }

  // ── Canvas frame rendering ────────────────────────────────────────────────────
  const img = new Image();
  img.addEventListener('load', () => {
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  });

  function renderFrame(base64) {
    img.src = 'data:image/jpeg;base64,' + base64;
  }

  // ── Coordinate scaling ────────────────────────────────────────────────────────
  function canvasCoords(e) {
    const rect  = canvas.getBoundingClientRect();
    const scaleX = canvas.width  / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: Math.round((e.clientX - rect.left) * scaleX),
      y: Math.round((e.clientY - rect.top)  * scaleY),
    };
  }

  function btnName(b) {
    return b === 2 ? 'right' : b === 1 ? 'middle' : 'left';
  }

  // ── Canvas input forwarding ───────────────────────────────────────────────────
  canvas.addEventListener('contextmenu', e => e.preventDefault());

  canvas.addEventListener('mousemove', e => {
    const { x, y } = canvasCoords(e);
    send({ type: 'mousemove', x, y });
  });

  canvas.addEventListener('mousedown', e => {
    canvas.focus();
    const { x, y } = canvasCoords(e);
    send({ type: 'mousedown', x, y, button: btnName(e.button) });
  });

  canvas.addEventListener('mouseup', e => {
    const { x, y } = canvasCoords(e);
    send({ type: 'mouseup', x, y, button: btnName(e.button) });
  });

  canvas.addEventListener('click', e => {
    const { x, y } = canvasCoords(e);
    send({ type: 'click', x, y, button: btnName(e.button) });
  });

  canvas.addEventListener('dblclick', e => {
    const { x, y } = canvasCoords(e);
    send({ type: 'dblclick', x, y });
  });

  canvas.addEventListener('wheel', e => {
    e.preventDefault();
    send({ type: 'wheel', deltaX: e.deltaX, deltaY: e.deltaY });
  }, { passive: false });

  canvas.addEventListener('keydown', e => {
    e.preventDefault();
    send({ type: 'keydown', key: e.key, code: e.code });
  });

  canvas.addEventListener('keyup', e => {
    e.preventDefault();
    send({ type: 'keyup', key: e.key, code: e.code });
  });

  // ── Navigation ────────────────────────────────────────────────────────────────
  function navigate(rawUrl) {
    let url = rawUrl.trim();
    if (!url) return;
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
    urlInput.value = url;
    setStatus(`로드 중: ${url}`);
    send({ type: 'navigate', url });
  }

  goBtn.addEventListener('click', () => navigate(urlInput.value));
  urlInput.addEventListener('keydown', e => { if (e.key === 'Enter') navigate(urlInput.value); });

  // ── Recording controls ────────────────────────────────────────────────────────
  recordBtn.addEventListener('click', () => {
    if (isRecording) {
      send({ type: 'stop-recording' });
    } else {
      send({ type: 'start-recording' });
    }
  });

  replayBtn.addEventListener('click', () => {
    if (selectedId !== null) replayRecording(selectedId);
  });

  // ── Replay ────────────────────────────────────────────────────────────────────
  function replayRecording(id) {
    const meta = recordings.find(r => r.id === id);
    if (!meta) return;
    replayingName = meta.name;
    setStatus(`재생 시작: ${meta.name}`);
    send({ type: 'replay', id, speedFactor: parseFloat(speedSelect.value) });
  }

  // ── Replay overlay ────────────────────────────────────────────────────────────
  function showOverlay(name, done, total) {
    ovName.textContent    = name;
    updateOverlay(done, total);
    overlay.classList.add('visible');
  }

  function updateOverlay(done, total) {
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;
    ovBar.style.width       = `${pct}%`;
    ovProgress.textContent  = total > 0
      ? `${done} / ${total} 이벤트 (${pct}%)`
      : '준비 중…';
  }

  function hideOverlay() {
    overlay.classList.remove('visible');
  }

  ovCancel.addEventListener('click', () => {
    hideOverlay();
    isReplaying = false;
    replayBtn.disabled  = selectedId === null;
    recordBtn.disabled  = false;
    setStatus('재생 취소됨.');
  });

  // ── Export ────────────────────────────────────────────────────────────────────
  async function exportJson(id) {
    try {
      const res = await fetch(`/api/recordings/${id}`);
      const rec = await res.json();
      const blob = new Blob([JSON.stringify(rec, null, 2)], { type: 'application/json' });
      triggerDownload(blob, `${safeName(rec.name)}.json`);
      setStatus(`JSON 내보내기 완료 — ${rec.name}`);
    } catch (err) {
      setStatus('JSON 내보내기 실패: ' + err.message);
    }
  }

  function exportScript(id) {
    const meta = recordings.find(r => r.id === id);
    const a = document.createElement('a');
    a.href = `/api/recordings/${id}/export/puppeteer`;
    a.download = `${safeName(meta?.name)}.js`;
    a.click();
    setStatus(`Puppeteer 스크립트 내보내기 — ${meta?.name}`);
  }

  function triggerDownload(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function safeName(name) {
    return (name || 'recording').replace(/[^\w\s-]/g, '_');
  }

  // ── Delete ────────────────────────────────────────────────────────────────────
  function deleteRecording(id) {
    send({ type: 'delete-recording', id });
    setStatus('녹화 삭제됨.');
  }

  // ── Render recording list ─────────────────────────────────────────────────────
  function renderList() {
    recCount.textContent = `${recordings.length}개`;

    if (recordings.length === 0) {
      recList.innerHTML = '<p class="empty-msg">아직 녹화가 없습니다.</p>';
      return;
    }

    recList.innerHTML = recordings
      .slice()
      .reverse()
      .map(rec => {
        const isSel = rec.id === selectedId;
        return `
<div class="rec-item${isSel ? ' selected' : ''}" data-id="${rec.id}">
  <div class="rec-item-head">
    <span class="rec-num">#${rec.id}</span>
    <button class="rec-del" data-id="${rec.id}" title="삭제">✕</button>
  </div>
  <span class="rec-url" title="${esc(rec.url)}">${esc(trimUrl(rec.url))}</span>
  <div class="rec-meta">
    <span>${rec.eventCount}개 이벤트</span>
    <span>${fmtTime(rec.createdAt)}</span>
  </div>
  <div class="rec-actions">
    <button class="btn-rec-replay" data-id="${rec.id}">▶ 재생</button>
  </div>
  <div class="rec-export">
    <button class="btn-rec-json"   data-id="${rec.id}" title="JSON으로 내보내기">📥 JSON</button>
    <button class="btn-rec-script" data-id="${rec.id}" title="Puppeteer 스크립트로 내보내기">📜 Script</button>
  </div>
</div>`;
      })
      .join('');
  }

  recList.addEventListener('click', e => {
    const del     = e.target.closest('.rec-del');
    const rep     = e.target.closest('.btn-rec-replay');
    const xjson   = e.target.closest('.btn-rec-json');
    const xscript = e.target.closest('.btn-rec-script');
    const item    = e.target.closest('.rec-item');

    if (del)     { e.stopPropagation(); deleteRecording(+del.dataset.id);   return; }
    if (rep)     { e.stopPropagation(); replayRecording(+rep.dataset.id);   return; }
    if (xjson)   { e.stopPropagation(); exportJson(+xjson.dataset.id);      return; }
    if (xscript) { e.stopPropagation(); exportScript(+xscript.dataset.id);  return; }
    if (item) {
      selectedId = +item.dataset.id;
      replayBtn.disabled = false;
      renderList();
    }
  });

  // ── Helpers ───────────────────────────────────────────────────────────────────
  function trimUrl(url) {
    try {
      const u = new URL(url);
      return u.hostname + (u.pathname === '/' ? '' : u.pathname);
    } catch { return url; }
  }

  function fmtTime(iso) {
    try { return new Date(iso).toLocaleTimeString('ko-KR'); }
    catch { return ''; }
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ── Boot ──────────────────────────────────────────────────────────────────────
  canvas.width  = viewport.width;
  canvas.height = viewport.height;
  connect();

})();
